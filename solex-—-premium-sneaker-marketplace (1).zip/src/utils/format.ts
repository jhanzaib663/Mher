/**
 * Format numerical amounts to Pakistani Rupee (PKR / Rs.) currency display
 */
export const formatPKR = (amount: number): string => {
  return `Rs. ${Math.round(amount).toLocaleString('en-PK')}`;
};
